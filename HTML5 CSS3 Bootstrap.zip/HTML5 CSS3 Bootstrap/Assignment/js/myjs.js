function si(txtPA,txtROI,txtNY){
    a=parseFloat(txtPA.value);
    b=parseFloat(txtROI.value);
    c=parseFloat(txtNY.value);
    result=(a*b*c)/100;
   // alert('Addition is : ' +result)
   document.getElementById("result").innerHTML='Simple Interest is '+result;

}
function clearAll()
{
    document.getElementById("result").innerHTML=" ";
}
// function addition(fn,sn){
//     a=parseFloat(fn.value);
//     b=parseFloat(sn.value);
//     result=a+b;
//    // alert('Addition is : ' +result)
//    document.getElementById("result").innerHTML='Addition is '+result;

// }
function addition(cform){
    if(cform.checkValidity()){
var f=parseFloat(cform.txtFN.value);
var s=parseFloat(cform.txtSN.value);
var result=f+s;
alert('Addition is '+result);
}
}



// function addition(){
//     var fn=parseFloat(cform.txtFN.value);     
//     var sn=parseFloat(cform.txtSN.value);                            
//     var result=fn+sn;
    
//     document.getElementById("result").innerHTML='Addition is '+result;
    
    
//     }



function subtraction(fn,sn){
    fn=parseFloat(fn.value);
   sn =parseFloat(sn.value);
    result=fn-sn;
   document.getElementById("result").innerHTML='Subtraction is '+result;

}
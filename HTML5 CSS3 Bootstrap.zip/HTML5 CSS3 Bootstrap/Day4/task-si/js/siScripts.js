function calculateSI(pa, roi, noy) {
    var si = parseFloat(pa.value) 
                * parseFloat(roi.value) 
                        * parseInt(noy.value) / 100; 
                        
//alert('Simple Interest is '+si);    
document.getElementById("lblResult").innerText  
            = 'Simple Interest is '+si;
         }

function verifyUser()
{
    if(localStorage.getItem("Username")==null)
    {
        window.open("../index.html");
    }
}

function logOff()
{
    if(localStorage.Username){
         localStorage.removeItem("Username");
        localStorage.clear();
        window.open("../index.html")
    }



}
function verifyLogin(loginForm){
    if(loginForm.checkValidity())
    {
        var Username=loginForm.txtUN.value;
        var Password=loginForm.txtPD.value;
        if(Username==="admin@gmail.com" && Password==="1234")
        {
            alert('Login successful');
            localStorage.setItem("Username",Username);
            window.open("../pages/simpleInterest.html","_blank");
        }
        else
            alert('Invalid username or password')

    }

}
var listOfBoys=["Lakshay","Nihal","Preston"];
var listOfGirls=new Array("Swati","Rajnika","Monisha");

document.write("<h3>"+listOfBoys+"</h3>");
document.write("<h3>"+listOfGirls+"</h3>");
document.write("<h3>Girls count:"+listOfGirls.length+"</h3>");
document.write("<h3>Boys count:"+listOfBoys .length+"</h3>");

document.write("<h3>Boys list using for-in: </h3>");
for(var name in listOfBoys){
    document.write(listOfBoys[name].italics().toUpperCase()+"<br/>");
}

document.write("<h3>Boys list using for: </h3>");
for(var i=0;i<listOfBoys.length;i++)
{
    document.write(listOfBoys[i].toUpperCase().link()+"<br/>");
}

document.write("<h3>Boys list using for-of: </h3>");
for(var name of listOfBoys)
{
    document.write(name.bold().fontcolor('Red')+"<br/>");
}

listOfBoys.push("Sachith")
document.write("<h3>Boys list using for-in: </h3>");
for(var name in listOfBoys){
    document.write(listOfBoys[name].italics().toUpperCase()+"<br/>");
}

listOfBoys.unshift("Sachith")
document.write("<h3>Boys list after adding Sachith: </h3>");
for(var name in listOfBoys){
    document.write(listOfBoys[name].italics().toUpperCase()+"<br/>");
}

listOfBoys.pop()
document.write("<h3>Boys list after deleting from end : </h3>");
for(var name in listOfBoys){
    document.write(listOfBoys[name].italics().toUpperCase()+"<br/>");
}

listOfBoys.shift()
document.write("<h3>Boys list after deleting from begining : </h3>");
for(var name in listOfBoys){
    document.write(listOfBoys[name].italics().toUpperCase()+"<br/>");
}

document.write("<h3>List after concatenation : </h3>");
var listOfEmp=listOfBoys.concat(listOfGirls)
document.write(listOfEmp);

listOfEmp.sort();
document.write("<h3>List after sorting : </h3>");
document.write(listOfEmp);

listOfEmp.reverse();
document.write("<h3>List in descending order : </h3>");
document.write(listOfEmp);

var list=listOfEmp.join(" *** ");
document.write("<h3>List using delimiter : </h3>");
document.write(list);

var slist=listOfEmp.slice(2,4);
document.write("<h3>List after using slice: </h3>");
document.write(slist);

var splist=listOfEmp.splice(1,3);
document.write("<h3>List after using splice: </h3>");
document.write(splist);
document.write(listOfEmp);










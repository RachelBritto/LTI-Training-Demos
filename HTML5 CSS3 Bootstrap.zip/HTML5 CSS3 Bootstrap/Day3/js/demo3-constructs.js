function checkEvenOdd()
{
   var num=parseInt(prompt("Enter number : ",0))

   var result=(num==0)?num+" is neither even nor odd...!"
                      :(num%2==0) ? num+" is even number....!"
                      :num+"is odd number....!";
                    
      document.getElementById("result").innerHTML=result;
   
}

function checkMax()
{
    var result
    var a=parseInt(prompt("Enter first number : ",0))
    var b=parseInt(prompt("Enter second number : ",0))
    if(a>b)
    result=a+ "is the max number"
    else if(a==b)
    result="Both are same!!!!"
    else
    result=b+ "is the max number"
    document.getElementById("result").innerHTML=result;

}

function checkVowels()
{
    var result;
    var c=prompt("Enter the alphabet : ")
   
   
    if(isNaN(c)){
    switch(c.toLowerCase())
    {
       
        case 'a': 
        case 'e':
        case 'i':
        case 'o':
        case 'u':
        result=(c + " is a vowel.");
        break;
			
            default: result=(c + " is a consonant.");
			break;       
  }
    document.getElementById("result").innerHTML=result
   
}
else
alert("Enter alphabet between [a-z] or [A-Z]")

}

function whileCheck()
{
    var n=parseInt(prompt("Enter a number: ",0));
    var numbers=0;
    //Step1:Initialization
    var i=1;
    //Step2:Test condition
    while(i<=n)
    {
        numbers=numbers+","+i;  //Step3:Body of the loop
        i++ ;        //Step4:Increment or decrement
    }
    document.getElementById("result").innerHTML="NUMBERS FROM 1 TO "+n+" are <br/>"+numbers;
    

}

function findFact()
{
    var num=parseInt(prompt("Enter a number: ",0));
    var fact=1;
    //Initialization condition and increment
    for(var i=1;i<=num;i++)
    {
        fact*=i;   //body
    }
    document.getElementById("result").innerHTML="FACTORIAL of " +num+ " is "+fact;
}

//Do while
function sumOfConNumber()
{
    var num=parseInt(prompt("Enter a number: ",0));
    var sum=0;
    //Initialization
    var i=1;
    
    do{
        sum+=i;     //Body
        i++;        //Increment
    }while(i<=num);  //Condition
   
    document.getElementById("result").innerHTML="Sum is " +sum;
}
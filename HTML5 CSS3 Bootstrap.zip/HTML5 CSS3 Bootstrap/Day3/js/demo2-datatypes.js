var anyType;
document.write("anyType: "+anyType+"<br/>"+"typeof(anyType) <b><i>"+typeof(anyType)+"</i></b><br/>")
anyType="LTI"
document.write("anyType: "+anyType+"<br/>"+"typeof(anyType) <b><i>"+typeof(anyType)+"</i></b><br/>")
anyType='g'
document.write("anyType: "+anyType+"<br/>"+"typeof(anyType) <b><i>"+typeof(anyType)+"</i></b><br/>")
anyType=104.3
document.write("anyType: "+anyType+"<br/>"+"typeof(anyType)<b><i>"+typeof(anyType)+"</i></b><br/>")
anyType='144'
document.write("anyType: "+anyType+"<br/>"+"typeof(anyType)<b><i>"+typeof(anyType)+"</i></b><br/>")
anyType=true
document.write("anyType: "+anyType+"<br/>"+"typeof(anyType)<b><i>"+typeof(anyType)+"</i></b><br/>")
anyType=null
document.write("anyType: "+anyType+"<br/>"+"typeof(anyType)<b><i>"+typeof(anyType)+"</i></b><br/>")
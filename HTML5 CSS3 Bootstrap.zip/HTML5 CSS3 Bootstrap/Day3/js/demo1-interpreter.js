document.write(1);
document.write(2);
document.write(3);
var name;
document.write(name);
